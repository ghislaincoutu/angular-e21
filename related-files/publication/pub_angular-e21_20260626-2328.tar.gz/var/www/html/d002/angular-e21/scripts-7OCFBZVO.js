function playSound(a,t){var e=document.createElement("audio"),i="fiches/"+a+"/medias/"+t+".mp3";e.setAttribute("src",i),e.play()}
